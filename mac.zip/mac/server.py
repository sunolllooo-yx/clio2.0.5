#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Clio · 本地服务（跨平台：Windows / macOS / Linux）
- 仅使用 Python 标准库，零第三方依赖
- 提供：静态文件服务 + 数据读写（原子写）+ 备份 / 恢复 / 导出
- 用法：
    python server.py                 # 以脚本所在目录为数据目录，端口 8765，自动打开
    python server.py --no-open       # 不自动打开
    python server.py --dir <目录>    # 指定数据目录（测试用）
    python server.py --port <端口>   # 指定端口（测试用）
"""

import argparse
import datetime
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import urllib.request
import webbrowser
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import quote, unquote, urlparse

MAIN_HTML = "clio.html"
DEFAULT_PORT = 8765
APP_NAME = "Clio 2.0"
APP_VERSION = "2.0.5"
START_TIME = time.time()
MAX_BODY = 1024 * 1024 * 1024  # 单次请求上限 1GB，防止异常请求把内存吃满
# 打包成单文件 exe 时（PyInstaller），资源被解到临时目录，程序在 sys.executable 旁
FROZEN = getattr(sys, "frozen", False)


def app_dir():
    """程序所在目录：脚本模式=server.py 所在目录；exe 模式=exe 所在目录。
    用户数据（data.json / media / backups）永远放在这里，而非临时解包目录。"""
    if FROZEN:
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def bundle_dir():
    """内置资源目录：单文件 exe 运行时为临时解包目录，否则同 app_dir。"""
    return getattr(sys, "_MEIPASS", app_dir())


LOG_DIR = [None]   # 由 main() 设置为实际数据目录


def log_error(where, exc=None):
    """把异常写进数据目录下的 clio-error.log（只追加，最多保留最近 200KB），
    方便出问题时定位；控制台同时打印一份。"""
    try:
        path = os.path.join(LOG_DIR[0] or app_dir(), "clio-error.log")
        if os.path.exists(path) and os.path.getsize(path) > 200 * 1024:
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    tail = f.read()[-60000:]
                with open(path, "w", encoding="utf-8") as f:
                    f.write(tail)
            except OSError:
                pass
        stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if isinstance(exc, str):
            text = exc
        elif exc is None:
            text = ""
        else:
            text = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        with open(path, "a", encoding="utf-8") as f:
            f.write("[%s] %s\n%s\n" % (stamp, where, text))
    except Exception:  # noqa: BLE001
        pass
    if exc is not None:
        try:
            traceback.print_exception(type(exc), exc, exc.__traceback__)
        except Exception:  # noqa: BLE001
            pass

def write_bytes_retry(path, data, tries=5):
    """写文件并重试：同步盘 / 杀毒软件会短暂占用文件，一次失败不代表真的写不进去。"""
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    last = None
    for i in range(tries):
        try:
            with open(path, "wb") as f:
                f.write(data)
                f.flush()
                try:
                    os.fsync(f.fileno())
                except OSError:
                    pass
            return
        except OSError as e:
            last = e
            time.sleep(0.08 * (i + 1))
    raise last if last else OSError("写入文件失败")


CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".txt": "text/plain; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".ico": "image/x-icon",
    ".mp4": "video/mp4",
    ".webm": "video/webm",
    ".mov": "video/quicktime",
    ".mkv": "video/x-matroska",
    ".avi": "video/x-msvideo",
    ".m4v": "video/mp4",
    ".mp3": "audio/mpeg",
    ".wav": "audio/wav",
    ".ogg": "audio/ogg",
    ".m4a": "audio/mp4",
    ".flac": "audio/flac",
    ".aac": "audio/aac",
}


def initial_data():
    """首次运行时的初始数据结构（V2）。"""
    return {
        "version": 2,
        "tags": {"red": [], "blue": []},
        "posts": [],
        "diaries": [],
        "comics": [],
        "piles": [],
        "media": [],
        "conversations": [],
        "demoSeeded": False,
        "settings": {},
    }


class Workspace:
    def __init__(self, base_dir):
        self.base_dir = os.path.abspath(base_dir)
        self.data_file = os.path.join(self.base_dir, "data.json")
        self.backup_dir = os.path.join(self.base_dir, "backups")
        self.media_dir = os.path.join(self.base_dir, "media")
        self.thumb_dir = os.path.join(self.media_dir, "thumb")

    def ensure(self):
        os.makedirs(self.base_dir, exist_ok=True)
        os.makedirs(self.backup_dir, exist_ok=True)
        for sub in ("image", "video", "audio", "cover", "thumb"):
            os.makedirs(os.path.join(self.media_dir, sub), exist_ok=True)
        if not os.path.exists(self.data_file):
            self.atomic_write(initial_data())

    def atomic_write(self, obj):
        """原子写：先写临时文件再替换，避免中途断电损坏数据。
        杀毒软件 / 同步盘偶尔会短暂占用文件，失败时重试几次再放弃。"""
        data = json.dumps(obj, ensure_ascii=False, indent=2)
        tmp = self.data_file + ".tmp"
        last = None
        for i in range(5):
            try:
                with open(tmp, "w", encoding="utf-8") as f:
                    f.write(data)
                    f.flush()
                    try:
                        os.fsync(f.fileno())
                    except OSError:
                        pass
                os.replace(tmp, self.data_file)
                return
            except OSError as e:
                last = e
                time.sleep(0.12 * (i + 1))
        raise last if last else OSError("写入数据失败")

    def read(self):
        self.ensure()
        with open(self.data_file, "r", encoding="utf-8") as f:
            return json.load(f)

    def timestamp(self):
        return datetime.datetime.now().strftime("%Y%m%d-%H%M%S")

    def make_backup(self):
        """复制当前数据文件为带时间戳的备份，返回备份文件名。"""
        self.ensure()
        name = "Clio-%s.json" % self.timestamp()
        target = os.path.join(self.backup_dir, name)
        seq = 1
        while os.path.exists(target):
            target = os.path.join(self.backup_dir, "%s-%d.json" % (name[:-5], seq))
            seq += 1
        shutil.copy2(self.data_file, target)
        return os.path.basename(target)

    def list_backups(self):
        items = []
        if os.path.isdir(self.backup_dir):
            for fn in os.listdir(self.backup_dir):
                if fn.endswith(".json"):
                    p = os.path.join(self.backup_dir, fn)
                    st = os.stat(p)
                    items.append({
                        "name": fn,
                        "type": "json",
                        "size": st.st_size,
                        "mtime": datetime.datetime.fromtimestamp(st.st_mtime).isoformat(timespec="seconds"),
                    })
                elif fn.endswith(".zip"):
                    p = os.path.join(self.backup_dir, fn)
                    st = os.stat(p)
                    items.append({
                        "name": fn,
                        "type": "full",
                        "size": st.st_size,
                        "mtime": datetime.datetime.fromtimestamp(st.st_mtime).isoformat(timespec="seconds"),
                    })
        items.sort(key=lambda x: x["mtime"], reverse=True)
        return items

    def restore(self, name):
        """按备份文件名恢复（只允许 backups 目录内文件，防路径穿越）。"""
        safe = os.path.basename(name)
        src = os.path.join(self.backup_dir, safe)
        if not os.path.exists(src):
            raise FileNotFoundError("备份不存在：%s" % safe)
        with open(src, "r", encoding="utf-8") as f:
            obj = json.load(f)
        self.atomic_write(obj)
        return safe

    # ---------------- 完整备份（zip：data + media，流式，跳过缩略图） ----------------
    def make_full_backup(self):
        """生成完整备份 zip：data.json + 原始媒体，跳过可重建的 thumb 目录。
        返回 (文件名, 字节数, 媒体文件数)。逐文件写入，不整体载入内存。"""
        self.ensure()
        ts = self.timestamp()
        name = "Clio-full-%s.zip" % ts
        target = os.path.join(self.backup_dir, name)
        seq = 1
        while os.path.exists(target):
            target = os.path.join(self.backup_dir, "Clio-full-%s-%d.zip" % (ts, seq))
            seq += 1
        count = 0
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as z:
            z.write(self.data_file, "data.json")
            if os.path.isdir(self.media_dir):
                for root, _dirs, files in os.walk(self.media_dir):
                    for fn in sorted(files):
                        full = os.path.join(root, fn)
                        rel = os.path.relpath(full, self.base_dir).replace(os.sep, "/")
                        if rel.startswith("media/thumb/"):
                            continue  # 缩略图可重建，跳过以减小体积
                        z.write(full, rel)
                        count += 1
        return os.path.basename(target), os.path.getsize(target), count

    def restore_full(self, name):
        """从完整备份 zip 恢复：校验路径安全后解出 data.json 与原始媒体。
        缩略图不在备份内，由前端在恢复后按需重建。"""
        safe = os.path.basename(name)
        src = os.path.join(self.backup_dir, safe)
        if not os.path.exists(src):
            raise FileNotFoundError("备份不存在：%s" % safe)
        if not zipfile.is_zipfile(src):
            raise ValueError("不是有效的备份文件：%s" % safe)
        with zipfile.ZipFile(src) as z:
            for member in z.namelist():
                m = member.replace("\\", "/")
                if m.startswith("/") or ".." in m.split("/"):
                    raise ValueError("备份包含非法路径：%s" % member)
                if not (m == "data.json" or m.startswith("media/")):
                    raise ValueError("备份包含非预期内容：%s" % member)
            if "data.json" not in z.namelist():
                raise ValueError("备份缺少 data.json")
            # 解到临时目录，再原子替换 data.json、并入媒体
            tmp = tempfile.mkdtemp(prefix="clio_restore_")
            try:
                z.extractall(tmp)
                new_data = os.path.join(tmp, "data.json")
                with open(new_data, "r", encoding="utf-8") as f:
                    obj = json.load(f)
                self.atomic_write(obj)
                tmp_media = os.path.join(tmp, "media")
                if os.path.isdir(tmp_media):
                    for root, _dirs, files in os.walk(tmp_media):
                        for fn in files:
                            full = os.path.join(root, fn)
                            rel = os.path.relpath(full, tmp).replace(os.sep, "/")
                            dest = os.path.join(self.base_dir, rel)
                            os.makedirs(os.path.dirname(dest), exist_ok=True)
                            shutil.copy2(full, dest)
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
        return safe

    # ---------------- 媒体 ----------------
    def _safe_ext(self, name):
        ext = os.path.splitext(os.path.basename(name or ""))[1].lower()
        # 只保留字母数字，长度受限，防止怪异扩展名
        ext = "".join(c for c in ext if c.isalnum() or c == ".")[:10]
        return ext

    def save_upload(self, kind, name, data):
        """保存原始上传文件，返回媒体 id 与可访问 URL。"""
        self.ensure()
        if kind not in ("image", "video", "audio", "cover"):
            raise ValueError("kind 非法")
        if not data:
            raise ValueError("文件是空的，请重新选择")
        mid = "m_" + datetime.datetime.now().strftime("%Y%m%d%H%M%S") + \
              "_" + os.urandom(3).hex()
        ext = self._safe_ext(name)
        rel = "%s/%s%s" % (kind, mid, ext)
        full = os.path.join(self.media_dir, rel)
        write_bytes_retry(full, data)
        return {"id": mid, "url": "/media/" + rel, "size": len(data),
                "name": os.path.basename(name or "")}

    def save_thumb(self, mid, data):
        """保存某媒体的缩略图（jpg）。"""
        self.ensure()
        safe = os.path.basename(mid)
        rel = "thumb/%s.jpg" % safe
        write_bytes_retry(os.path.join(self.media_dir, rel), data)
        return "/media/" + rel

    def media_full_path(self, rel):
        """把 /media 下的相对路径解析为绝对路径，防穿越。"""
        full = os.path.normpath(os.path.join(self.media_dir, rel))
        if full != self.media_dir and not full.startswith(self.media_dir + os.sep):
            return None
        return full

    def is_media_referenced(self, mid):
        """扫描 data.json，判断该媒体 id 是否仍被任何记录引用。"""
        try:
            data = self.read()
        except Exception:
            return True
        blob = json.dumps(data, ensure_ascii=False)
        return mid in blob

    def delete_media(self, mid):
        """删除媒体文件与缩略图（含引用检查）。"""
        safe = os.path.basename(mid)
        if self.is_media_referenced(safe):
            raise ValueError("该媒体仍被引用，请先从相关记录中移除")
        removed = []
        for root, _dirs, files in os.walk(self.media_dir):
            for fn in files:
                # 文件名以 id 开头（原图）或等于 id.jpg（缩略图）
                if fn == safe + ".jpg" or fn.startswith(safe + "."):
                    p = os.path.join(root, fn)
                    os.remove(p)
                    removed.append(p)
        return removed


def make_handler(ws):
    class Handler(BaseHTTPRequestHandler):
        server_version = "Clio/1.0"
        protocol_version = "HTTP/1.0"

        def log_message(self, fmt, *args):
            pass

        def _send_json(self, obj, status=200):
            try:
                body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass  # 浏览器提前断开，忽略即可

        def _read_body(self):
            """读取请求体：兼容 Content-Length 与 chunked（fetch 的流式请求没有长度）。"""
            te = (self.headers.get("Transfer-Encoding") or "").lower()
            if "chunked" in te:
                chunks, total = [], 0
                while True:
                    line = self.rfile.readline(65536).strip()
                    if not line:
                        break
                    try:
                        size = int(line.split(b";")[0], 16)
                    except ValueError:
                        break
                    if size <= 0:
                        self.rfile.readline(65536)
                        break
                    total += size
                    if total > MAX_BODY:
                        raise ValueError("请求体过大")
                    chunks.append(self.rfile.read(size))
                    self.rfile.readline(65536)  # 结尾 CRLF
                return b"".join(chunks)
            raw_len = self.headers.get("Content-Length") or "0"
            try:
                length = int(raw_len)
            except (TypeError, ValueError):
                length = 0
            if length > MAX_BODY:
                raise ValueError("请求体过大")
            if length <= 0:
                return b""
            data = self.rfile.read(length)
            if len(data) != length:
                # 客户端中途断开：宁可报错，也不要把半个文件当成完整文件存下来
                raise ValueError("上传中断（收到 %d / %d 字节）" % (len(data), length))
            return data

        def do_GET(self):
            path = urlparse(self.path).path
            try:
                if path == "/api/ping":
                    self._send_json({"ok": True, "app": "clio", "dir": ws.base_dir,
                                     "pid": os.getpid()})
                    return
                if path == "/api/health":
                    self._send_json(self._health())
                    return
                if path == "/api/data":
                    self._send_json(ws.read())
                    return
                if path == "/api/backups":
                    self._send_json({"ok": True, "backups": ws.list_backups()})
                    return
                if path == "/api/export":
                    self._handle_export()
                    return
                if path.startswith("/media/"):
                    self._serve_media(path[len("/media/"):])
                    return
                self._serve_static(path)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as e:  # noqa: BLE001
                log_error("GET %s" % self.path, e)
                self._send_json({"ok": False, "error": str(e)}, 500)

        def _health(self):
            """自检：目录是否可写、数据多大、多少媒体。出问题时先看这个。"""
            writable = True
            detail = ""
            try:
                ws.ensure()
                probe = os.path.join(ws.media_dir, ".probe")
                with open(probe, "wb") as f:
                    f.write(b"ok")
                os.remove(probe)
            except Exception as e:  # noqa: BLE001
                writable = False
                detail = str(e)
            media_count = 0
            try:
                for _root, _dirs, files in os.walk(ws.media_dir):
                    media_count += len(files)
            except OSError:
                pass
            data_size = 0
            try:
                data_size = os.path.getsize(ws.data_file)
            except OSError:
                pass
            return {"ok": writable, "app": "clio", "version": APP_VERSION,
                    "dir": ws.base_dir, "pid": os.getpid(),
                    "writable": writable, "detail": detail,
                    "mediaCount": media_count, "dataSize": data_size,
                    "uptime": round(time.time() - START_TIME, 1)}

        def do_POST(self):
            path = urlparse(self.path).path
            qs = urlparse(self.path).query
            params = dict(p.split("=", 1) for p in qs.split("&") if "=" in p)
            # 读请求体失败绝不能直接断连接：浏览器那边只会看到
            # "Failed to fetch"，完全不知道发生了什么。这里统一兜住并回明确错误。
            try:
                body = self._read_body()
            except (BrokenPipeError, ConnectionResetError):
                return
            except Exception as e:  # noqa: BLE001
                log_error("READ %s" % self.path, e)
                self._send_json({"ok": False, "error": str(e) or "读取请求失败"}, 413)
                return
            try:
                if path == "/api/data":
                    obj = json.loads(body.decode("utf-8") or "null")
                    if not isinstance(obj, dict):
                        raise ValueError("数据必须是 JSON 对象")
                    ws.atomic_write(obj)
                    self._send_json({"ok": True})
                    return
                if path == "/api/backup":
                    name = ws.make_backup()
                    self._send_json({"ok": True, "name": name})
                    return
                if path == "/api/restore":
                    req = json.loads(body.decode("utf-8") or "{}")
                    safe = ws.restore(req.get("name", ""))
                    self._send_json({"ok": True, "name": safe})
                    return
                if path == "/api/backup/full":
                    fname, size, mcount = ws.make_full_backup()
                    self._send_json({"ok": True, "name": fname, "size": size, "mediaCount": mcount})
                    return
                if path == "/api/restore/full":
                    req = json.loads(body.decode("utf-8") or "{}")
                    safe = ws.restore_full(req.get("name", ""))
                    self._send_json({"ok": True, "name": safe})
                    return
                if path == "/api/log":
                    try:
                        info = json.loads(body.decode("utf-8") or "{}")
                        if not isinstance(info, dict):
                            info = {}
                    except Exception:  # noqa: BLE001
                        info = {"message": body[:1000].decode("utf-8", "replace")}
                    log_error("UI %s" % (info.get("where") or ""),
                              "%s\n%s" % (info.get("message", ""), info.get("stack", "")))
                    self._send_json({"ok": True})
                    return
                if path == "/api/upload":
                    kind = unquote(params.get("kind", ""))
                    name = unquote(params.get("name", ""))
                    self._send_json({"ok": True, "file": ws.save_upload(kind, name, body)})
                    return
                if path == "/api/upload/thumb":
                    mid = unquote(params.get("id", ""))
                    thumb = ws.save_thumb(mid, body)
                    self._send_json({"ok": True, "thumb": thumb})
                    return
                self._send_json({"ok": False, "error": "接口不存在"}, 404)
            except FileNotFoundError as e:
                self._send_json({"ok": False, "error": str(e)}, 404)
            except ValueError as e:
                self._send_json({"ok": False, "error": str(e)}, 400)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as e:  # noqa: BLE001
                log_error("POST %s" % self.path, e)
                self._send_json({"ok": False, "error": str(e)}, 500)

        def do_DELETE(self):
            path = urlparse(self.path).path
            qs = urlparse(self.path).query
            params = dict(p.split("=", 1) for p in qs.split("&") if "=" in p)
            try:
                if path == "/api/media":
                    mid = unquote(params.get("id", ""))
                    ws.delete_media(mid)
                    self._send_json({"ok": True})
                    return
                self._send_json({"ok": False, "error": "接口不存在"}, 404)
            except ValueError as e:
                self._send_json({"ok": False, "error": str(e)}, 400)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as e:  # noqa: BLE001
                log_error("DELETE %s" % self.path, e)
                self._send_json({"ok": False, "error": str(e)}, 500)

        def _handle_export(self):
            ws.ensure()
            with open(ws.data_file, "rb") as f:
                data = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header(
                "Content-Disposition",
                "attachment; filename*=UTF-8''" + quote("data.json"),
            )
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

        def _serve_static(self, url_path):
            rel = unquote(url_path.lstrip("/"))
            if not rel:
                rel = MAIN_HTML
            full = os.path.normpath(os.path.join(ws.base_dir, rel))
            if full != ws.base_dir and not full.startswith(ws.base_dir + os.sep):
                self.send_error(403, "Forbidden")
                return
            if os.path.isdir(full):
                full = os.path.join(full, MAIN_HTML)
            if not os.path.exists(full):
                # 单文件 exe：clio.html 内置在 exe 里；用户目录下有同名文件时优先用用户的
                bdir = bundle_dir()
                alt = os.path.normpath(os.path.join(bdir, rel))
                if alt.startswith(bdir + os.sep) and os.path.isfile(alt):
                    full = alt
            if not os.path.exists(full):
                self.send_error(404, "Not Found")
                return
            ext = os.path.splitext(full)[1].lower()
            ctype = CONTENT_TYPES.get(ext, "application/octet-stream")
            with open(full, "rb") as f:
                data = f.read()
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _serve_media(self, rel):
            """提供媒体文件，支持 Range（206），用于视频/音频拖动与续播。"""
            rel = unquote(rel)
            full = ws.media_full_path(rel)
            if not full or not os.path.exists(full) or os.path.isdir(full):
                self.send_error(404, "Not Found")
                return
            ext = os.path.splitext(full)[1].lower()
            ctype = CONTENT_TYPES.get(ext, "application/octet-stream")
            fsize = os.path.getsize(full)
            range_hdr = self.headers.get("Range")
            start, end = 0, fsize - 1
            if range_hdr and range_hdr.startswith("bytes="):
                try:
                    spec = range_hdr[6:].split(",")[0].split("-")
                    if spec[0]:
                        start = int(spec[0])
                    if spec[1]:
                        end = int(spec[1])
                    if start > end or start >= fsize:
                        raise ValueError
                    end = min(end, fsize - 1)
                    length = end - start + 1
                    self.send_response(206)
                    self.send_header("Content-Type", ctype)
                    self.send_header("Content-Length", str(length))
                    self.send_header("Accept-Ranges", "bytes")
                    self.send_header("Content-Range",
                                     "bytes %d-%d/%d" % (start, end, fsize))
                    self.end_headers()
                    with open(full, "rb") as f:
                        f.seek(start)
                        remaining = length
                        while remaining > 0:
                            chunk = f.read(min(1 << 20, remaining))
                            if not chunk:
                                break
                            self.wfile.write(chunk)
                            remaining -= len(chunk)
                    return
                except (ValueError, IndexError):
                    self.send_error(416, "Range Not Satisfiable")
                    return
            # 无 Range：整文件返回
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(fsize))
            self.send_header("Accept-Ranges", "bytes")
            self.end_headers()
            with open(full, "rb") as f:
                shutil.copyfileobj(f, self.wfile, length=1 << 20)

    return Handler


def find_app_browser():
    """寻找本机可用的 Edge/Chrome，返回可执行文件路径；找不到返回 None。"""
    if sys.platform == "darwin":
        candidates = [
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            os.path.expanduser("~/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"),
            os.path.expanduser("~/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
        ]
        for p in candidates:
            if os.path.exists(p):
                return p
        return None
    if sys.platform.startswith("win"):
        env = os.environ
        bases = [
            env.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"),
            env.get("PROGRAMFILES", r"C:\Program Files"),
            env.get("LOCALAPPDATA", ""),
        ]
        rels = [
            r"Microsoft\Edge\Application\msedge.exe",
            r"Google\Chrome\Application\chrome.exe",
        ]
        for base in bases:
            if not base:
                continue
            for rel in rels:
                p = os.path.join(base, rel)
                if os.path.exists(p):
                    return p
        return None
    # Linux / 其它
    for name in ("microsoft-edge", "google-chrome", "google-chrome-stable", "chromium", "chromium-browser"):
        p = shutil.which(name)
        if p:
            return p
    return None


def open_app_window(url):
    """优先用独立 App 窗口（无地址栏/标签页，像桌面软件）；否则退回普通浏览器。"""
    browser = find_app_browser()
    if browser:
        try:
            subprocess.Popen([
                browser,
                "--app=" + url,
                "--no-first-run",
                "--no-default-browser-check",
                "--window-size=1280,900",
                "--window-position=120,60",
            ])
            return True
        except OSError:
            pass
    webbrowser.open(url)
    return False


def ping_clio(port, timeout=0.8):
    """探测该端口上是否已经跑着一个 Clio。"""
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/api/ping" % port, timeout=timeout) as r:
            obj = json.loads(r.read().decode("utf-8", "replace") or "{}")
            return obj.get("app") == "clio"
    except Exception:  # noqa: BLE001
        return False


class InstanceLock:
    """单实例锁：同一数据目录只允许一个 Clio 在跑。

    Windows 的 SO_REUSEADDR 语义允许两个进程绑同一端口，所以不能靠端口判断，
    这里用独占文件锁（msvcrt / fcntl），进程退出时由系统自动释放。
    """

    def __init__(self, base_dir):
        self.lock_path = os.path.join(base_dir, ".clio.lock")
        self.port_path = os.path.join(base_dir, ".clio.port")
        self._fh = None

    def acquire(self):
        try:
            fh = open(self.lock_path, "a+b")
        except OSError as e:
            print("提示：无法创建实例锁（%s），仍继续启动。" % e)
            return True
        try:
            if os.path.getsize(self.lock_path) == 0:
                fh.write(b"\0")
                fh.flush()
            fh.seek(0)
            if sys.platform.startswith("win"):
                import msvcrt
                msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            # 文件打开了但锁不住 → 已经有 Clio 占着这把锁
            try:
                fh.close()
            except Exception:  # noqa: BLE001
                pass
            return False
        self._fh = fh
        return True

    def write_port(self, port):
        try:
            with open(self.port_path, "w", encoding="utf-8") as f:
                f.write(str(port))
        except OSError:
            pass

    @staticmethod
    def read_port(base_dir, default=DEFAULT_PORT):
        try:
            with open(os.path.join(base_dir, ".clio.port"), "r", encoding="utf-8") as f:
                return int(f.read().strip())
        except Exception:  # noqa: BLE001
            return default

    def release(self):
        if not self._fh:
            return
        try:
            if sys.platform.startswith("win"):
                import msvcrt
                self._fh.seek(0)
                msvcrt.locking(self._fh.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self._fh.fileno(), fcntl.LOCK_UN)
        except Exception:  # noqa: BLE001
            pass
        try:
            self._fh.close()
        except Exception:  # noqa: BLE001
            pass
        self._fh = None


def set_console_title(title):
    """Windows 控制台标题，方便在任务栏里认出来。其它平台忽略。"""
    if sys.platform.startswith("win"):
        try:
            import ctypes
            ctypes.windll.kernel32.SetConsoleTitleW(title)
        except Exception:  # noqa: BLE001
            pass


class ClioServer(ThreadingHTTPServer):
    """本地服务：每个请求一个守护线程，单请求异常不影响整个服务继续跑。"""
    daemon_threads = True
    # Windows 的 SO_REUSEADDR 允许"重复绑定同一个端口"：别的程序（比如老版
    # Clio 1.0 的本地服务）占着 8765 时，我们也能 bind 成功，但请求一条都收不到，
    # 全被对方接走 —— 页面于是读到别人的数据，表现成"图片/漫画/图堆全没了"。
    # Windows 上必须关掉地址复用，让端口冲突老实报错，才能走换端口逻辑；
    # macOS / Linux 保持开启，否则重启时 TIME_WAIT 会让 bind 失败。
    allow_reuse_address = not sys.platform.startswith("win")
    request_queue_size = 64

    def handle_error(self, request, client_address):
        exc = sys.exc_info()[1]
        if isinstance(exc, (BrokenPipeError, ConnectionResetError)):
            return
        log_error("handler %s" % (client_address,), exc)


def probe_port(port, timeout=0.8):
    """看端口上有没有别的程序：'free' 空闲 / 'clio' 是 Clio / 'other' 是别的东西。

    只靠 bind 判断不出占用（Windows 下会假成功），所以先连一下再问身份。
    """
    s = socket.socket()
    s.settimeout(timeout)
    try:
        s.connect(("127.0.0.1", port))
    except OSError:
        return "free"
    finally:
        try:
            s.close()
        except OSError:
            pass
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/api/ping" % port,
                                    timeout=timeout) as r:
            obj = json.loads(r.read().decode("utf-8", "replace") or "{}")
        return "clio" if obj.get("app") == "clio" else "other"
    except Exception:  # noqa: BLE001
        # 连得上但问不出身份（404 / 不是 JSON / 超时）→ 当成别的程序
        return "other"


def bind_server(port, handler):
    """绑定端口；被占用时自动改用空闲端口，避免启动即退出、也避免抢别人的端口。"""
    if port == 0:
        return ClioServer(("127.0.0.1", 0), handler)
    owner = probe_port(port)
    if owner != "free":
        who = "另一个 Clio" if owner == "clio" else "其它程序"
        print("端口 %d 已被%s占用，自动改用空闲端口…" % (port, who))
        return ClioServer(("127.0.0.1", 0), handler)
    try:
        return ClioServer(("127.0.0.1", port), handler)
    except OSError:
        print("端口 %d 被占用，自动改用空闲端口…" % port)
        return ClioServer(("127.0.0.1", 0), handler)


def writable_dir(path):
    """测试目录可写（能建目录、能落一个探针文件）。"""
    try:
        os.makedirs(path, exist_ok=True)
        probe = os.path.join(path, ".clio-write-test")
        with open(probe, "wb") as f:
            f.write(b"1")
        os.remove(probe)
        return True
    except OSError:
        return False


def pick_data_dir(preferred):
    """优先用程序所在目录；万一被放在只读位置（Program Files / 只读U盘 / 受控文件夹），
    自动退到用户目录，避免"窗口开着但服务起不来"这种整体不可用。"""
    if writable_dir(preferred):
        return preferred, False
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    alt = os.path.join(base, "Clio")
    if writable_dir(alt):
        return alt, True
    return preferred, False


def main():
    parser = argparse.ArgumentParser(description="Clio 本地服务")
    parser.add_argument("--dir", default=app_dir(),
                        help="数据目录（默认为程序所在目录）")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT, help="端口（默认 8765）")
    parser.add_argument("--no-open", action="store_true", help="不自动打开浏览器")
    args = parser.parse_args()

    set_console_title(APP_NAME)
    data_dir, moved = pick_data_dir(args.dir)
    if moved:
        print("提示：程序所在文件夹不可写，数据改存到：%s" % data_dir)
    args.dir = data_dir
    ws = Workspace(args.dir)
    LOG_DIR[0] = ws.base_dir      # 日志写在数据目录，用户一眼能找到
    try:
        ws.ensure()
    except OSError as e:
        log_error("初始化数据目录 %s" % args.dir, e)
        print("无法初始化数据目录：%s" % e)
        if FROZEN:
            input("按回车键关闭…")
        sys.exit(1)

    # 单实例：本目录已有 Clio 在跑，就把已有窗口唤出来再退出，绝不第二个实例写数据
    lock = InstanceLock(ws.base_dir)
    if not lock.acquire():
        port = InstanceLock.read_port(ws.base_dir, args.port)
        url = "http://127.0.0.1:%d/" % port
        print("Clio 已在运行，正在切换到已有窗口：%s" % url)
        if not args.no_open:
            open_app_window(url)
            time.sleep(0.8)
        return

    try:
        try:
            server = bind_server(args.port, make_handler(ws))
        except OSError as e:
            print("无法启动本地服务：%s" % e)
            print("请重试，或用 --port 指定其他端口。")
            if FROZEN:
                input("按回车键关闭…")
            sys.exit(1)

        actual_port = server.server_address[1]
        lock.write_port(actual_port)
        url = "http://127.0.0.1:%d/" % actual_port
        print("=" * 46)
        print(" %s 已启动" % APP_NAME)
        print(" 地址：%s" % url)
        print(" 数据：%s" % ws.base_dir)
        print(" 提示：关闭此窗口即退出 Clio（数据已自动保存）")
        print("=" * 46)
        if not args.no_open:
            open_app_window(url)
        try:
            # 服务循环兜底：某一轮异常退出时自动重开，尽量不让页面掉线
            while True:
                try:
                    server.serve_forever(poll_interval=0.4)
                    break
                except KeyboardInterrupt:
                    raise
                except Exception as e:  # noqa: BLE001
                    log_error("serve_forever", e)
                    time.sleep(0.6)
        except KeyboardInterrupt:
            print("\n服务已停止。")
        finally:
            try:
                server.server_close()
            except Exception:  # noqa: BLE001
                pass
    finally:
        lock.release()


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception:  # noqa: BLE001
        import traceback
        traceback.print_exc()
        if FROZEN:
            try:
                input("出错了，按回车键关闭…")
            except Exception:  # noqa: BLE001
                pass
