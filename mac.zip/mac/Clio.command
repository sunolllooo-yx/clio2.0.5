#!/bin/bash
# Clio 2.0.5 · macOS 启动器（双击即可运行）
# 数据保存在本文件夹的 data.json（跟着文件夹走，拷走即搬家）

cd "$(dirname "$0")" || exit 1
DIR="$(pwd)"

# 首次双击时若提示「权限不足 / 无法执行」，在「终端」执行一次：
#   chmod +x "$DIR/Clio.command"

dialog() {
  osascript -e "display dialog \"$1\" buttons {\"好\"} default button 1 with title \"Clio\" with icon note" >/dev/null 2>&1
}

ARCH="$(uname -m)"
PY=""

# 判断某个候选是否为可用的 Python 3
check_py() {
  local c="$1"
  [ -n "$c" ] || return 1
  if [ -x "$c" ] || command -v "$c" >/dev/null 2>&1; then
    if "$c" -c 'import sys; sys.exit(0 if sys.version_info[0] >= 3 else 1)' 2>/dev/null; then
      printf '%s' "$c"
      return 0
    fi
  fi
  return 1
}

# 1) 优先用同目录自带的便携运行时（如果你后来把它放进 runtime/ 了）
if [ "$ARCH" = "arm64" ]; then
  BUNDLED_DIR="runtime/arm64"
else
  BUNDLED_DIR="runtime/x64"
fi
PY="$(check_py "$DIR/$BUNDLED_DIR/bin/python3")"

# 2) 兜底：系统自带 / Homebrew / PATH 里的 python3
if [ -z "$PY" ]; then
  for c in /usr/bin/python3 /opt/homebrew/bin/python3 /usr/local/bin/python3 \
           /Library/Frameworks/Python.framework/Versions/Current/bin/python3 python3; do
    PY="$(check_py "$c")"
    [ -n "$PY" ] && break
  done
fi

# 3) 都没有：给一个能看懂的提示，并提供一键安装命令行工具的入口
if [ -z "$PY" ]; then
  echo ""
  echo "  Clio 需要一个 Python 3 才能启动，这台 Mac 上暂时没找到。"
  echo ""
  echo "  解决办法（二选一）："
  echo "    1) 在「终端」执行：xcode-select --install   （约 3 分钟，之后重新双击本文件）"
  echo "    2) 到 python.org 下载 macOS 版 Python 3 安装包，装完重新双击本文件"
  echo ""
  dialog "Clio 需要 Python 3 才能启动。点「好」后会弹出安装提示，装完再双击 Clio.command 即可。"
  osascript -e 'do shell script "xcode-select --install" with prompt "Clio 需要安装命令行开发工具（含 Python 3）"' >/dev/null 2>&1
  read -n 1 -r -s -p "按任意键关闭…"
  echo ""
  exit 1
fi

echo "Clio 正在启动…（Python：$PY）"
echo "数据目录：$DIR"
echo "关闭本窗口即可退出 Clio。"
echo ""

# 把数据目录显式指定为本文件夹，避免任何情况下写到别处
exec "$PY" "$DIR/server.py" --dir "$DIR"
